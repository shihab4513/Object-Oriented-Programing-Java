import java.util.Scanner;
public class Main {
    static boolean evencheck(int a){
        if (a%2==0){
            return true;
        }
        else
        {
            return false;
        }
    }
    public static void main(String[] args) {


        //System.out.println("Hello world!");
        Scanner shihab=new Scanner(System.in);
        int a=1,b=4;
        byte x=12;
        short aa=12;
        x=(byte) aa;
        char b='b';
        float c=2.67678676767687f;
        double d=2.67678676767687;
        boolean m=true;
        String s="hello world!";
        System.out.println("a: "+x);
        if (evencheck(a)){
            //print
        }
        else {
            //prit
        }

    }
}