public class AQ {
    double v1;
    int a1;
    int a,b;

    public AQ(double v1, int a1) {
        this.v1 = v1;
        this.a1 = a1;
        this.a=a;
        this.b=b;
    }

    public  AQ() {
        this.AQ(100);
    }




    void f1(int a, int b) {
        System.out.println(a + b + v1 + a1);
    }
    void f1(int x,int y){

        System.out.println(v1+a1+a+b);
    }
}
