public class Main {
    public static void main(String[] args)
    {
        int[] n= new int[]{1, 2, 3, 4};
        for (int x:n){
            x++;

        }
    }
}
