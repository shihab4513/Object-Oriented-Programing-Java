package p1;

public class Student2 {
}
