package p1;

public class Student2 extends University {
    int id;
    String
}
