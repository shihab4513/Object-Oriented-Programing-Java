package p1;

public class Test {
    public static void main(String[] args){
        Teacher t1=new Teacher();
        Student2 s1=new Student2();
        University u1=new University();
        System.out.println();
        s1.

    }
}
