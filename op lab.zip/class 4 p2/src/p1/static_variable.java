package p1;

public class static_variable {
    static int count=0;
    static_variable()
    {
        count++;
    }
   static void display(){
        System.out.println("Number of student: "+count);
    }
















}
