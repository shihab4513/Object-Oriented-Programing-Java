public class student {
    int  id;
    String name;
    public student(int id,String name){
        this.id=id;
        this.name=name;


    }

   public String toString()
   {
       return id+" "+name;
   }
}
