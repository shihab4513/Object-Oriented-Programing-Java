import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
    Scanner input=new Scanner(System.in);

    int id,n;
    String name;
    student s[]=new student[3];
   // n= input.nextInt();
      // for (int i = 0; i <s.length ; i++) {
      //     id= input.nextInt();
      //     input.nextLine();
      //     name= input.nextLine();
      //     s[i]=new student(id,name);

      // }
      // for (int i = 0; i <s.length ; i++) {

      //     System.out.println(s[i]);
      // }
        s[0]=s1;
    }
}