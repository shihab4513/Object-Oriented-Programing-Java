package pkg1;

public class b {
}
