package com.company;

public class Test2 {
    public static void main(String[] args)
    {
        animal a;

        a=new bird();
        //((bird)a).fly();
       // a.fly();
        a=new horse();
        a.sleep();
    }
}
