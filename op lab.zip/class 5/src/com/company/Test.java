package com.company;
import java.util.*;
public class Test {

    public static void main(String[] args) {
        //I've used method overriding here.
        //Madame has done same code using overloading.
       Rectengle r=new Rectengle(5.5,6.2);
       r.area();
       Triangle tr=new Triangle(9,4);
       tr.area();
       cercle c=new cercle(2);
       c.area();







    }
}
