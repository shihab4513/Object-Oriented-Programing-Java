package com.company;

public class cercle extends shape {
    cercle(double a)
    {
        super(a,a);

    }

    void area(){
        System.out.println("The area of cercle is: "+3.1416*a*a);

    }

}
