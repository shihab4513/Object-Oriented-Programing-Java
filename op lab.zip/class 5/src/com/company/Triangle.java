package com.company;

public class Triangle extends shape {
    Triangle(double a,double b){
        super(a,b);


    }
    void area(){
        System.out.println("The area of triangle is: "+0.5*a*b);
    }
}
