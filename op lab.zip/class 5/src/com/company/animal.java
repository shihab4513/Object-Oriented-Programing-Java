package com.company;

public class animal {
    void sleep(){
        System.out.println("ab");
    }

}
