package com.company;

public class horse extends animal {
    void sleep(){
        System.out.println("Horse");
    }
}
