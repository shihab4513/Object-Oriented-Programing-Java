package com.company;

public class bird extends animal {
    void fly(){
        System.out.println("b");
    }
}
