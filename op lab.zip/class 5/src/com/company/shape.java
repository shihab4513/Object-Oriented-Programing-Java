package com.company;

public class shape {
    double a,b;

    shape(double a,double b)
    {
        this.a = a;
        this.b = b;
    }
   // void area(){
//
//
   // }
}
